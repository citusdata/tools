import json
import os
import requests
import sys
import uuid

from OpenSSL.crypto import load_certificate, FILETYPE_PEM
from subprocess import check_output
from urllib.parse import urljoin

try:
    # Provide assistance if adal isn't present
    import adal
except Exception:
    print('Module [adal] not found. Try [sudo apt-get install python3-adal]', file=sys.stderr)
    exit(1)

class repolib:

    def error_and_exit(msg: str):
        print(msg, file=sys.stderr)
        exit(1)
    
    def __init__(self, server, port, AADClientId, AADResource, AADTenant,
        AADAuthorityUrl, AADClientSecret = None, AADClientCertificate = None, repositoryId = ''):
        # Parameters are named identically to the config values, so the entire config can be passed in
        self.base_url = 'https://{0}:{1}/v2/'.format(server, port)
        self.client_id = AADClientId
        if AADClientCertificate:
            self.client_certificate_path = AADClientCertificate
            try:
                with open(self.client_certificate_path, 'r') as f:
                    self.client_certificate_contents = f.read()
                cert = load_certificate(FILETYPE_PEM, self.client_certificate_contents)
                self.client_certificate_thumbprint = cert.digest('sha1').decode('utf-8')
            except Exception as e:
                repolib.error_and_exit('Error parsing client certificate {0}: {1}'.format(AADClientCertificate, str(e)))
        elif AADClientSecret:
            self.client_secret = AADClientSecret
        else:
            repolib.error_and_exit('Must provide either "AADClientSecret" or "AADClientCertificate"')
        self.resource = AADResource
        self.tenant = AADTenant
        self.authority_url = urljoin(AADAuthorityUrl, AADTenant)
        self.default_repository_id = repositoryId
        self.token = None
        self.verify_ssl = True
        
    def disable_ssl_verification(self):
        self.verify_ssl = False
    
    def _get_token(self):
        if self.token is None:
            self.auth_context = adal.AuthenticationContext(self.authority_url)
            try:
                if 'client_certificate_contents' in vars(self):
                    token_response = self.auth_context.acquire_token_with_client_certificate(self.resource, self.client_id,
                        self.client_certificate_contents, self.client_certificate_thumbprint)
                else:
                    token_response = self.auth_context.acquire_token_with_client_credentials(self.resource,
                        self.client_id, self.client_secret)

                self.token = token_response['accessToken']
            except adal.adal_error.AdalError as e:
                repolib.error_and_exit('Failed to acquire access token: {0}'.format(str(e)))
        return self.token
        
    def _get_headers(self, token):
        http_headers = {
            'Authorization': 'Bearer ' + token,
            'User-Agent': 'adal-python-sample',
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'client-request-id': str(uuid.uuid4())
        }
        return http_headers
        
    def _get_url(self, path):
        """
        Gets the specified URL from KeyVault using the auth token
        :param str url: URL to GET
        :return:        Dictionary representing keyvault response
        :rtype:         dict
        :raises:        ConnectionError, Exception, ValueError
        """
        msg_template = 'Connection Error while getting {0}: {1}'
        token = self._get_token()
        url = urljoin(self.base_url, path)
        http_headers = self._get_headers(token)
        try:
            resp = requests.get(url, headers=http_headers, stream=False, verify=self.verify_ssl)
        except ConnectionError as ex:
            detail = 'Error: {0}'.format(str(ex))
            raise ConnectionError(msg_template.format(url, detail))
        except requests.exceptions.SSLError as e:
            msg = 'Failed to reach API server due to SSL error {0}'
            repolib.error_and_exit(msg.format(e))
        if resp.status_code != 200:
            detail = 'Status code: {0}'.format(resp.status_code)
            raise Exception(msg_template.format(url, detail))
        return resp

    def _delete_url(self, path):
        msg_template = 'Connection Error while getting {0}: {1}'
        token = self._get_token()
        url = urljoin(self.base_url, path)
        http_headers = self._get_headers(token)
        try:
            resp = requests.delete(url, headers=http_headers, stream=False, verify=self.verify_ssl)
        except ConnectionError as ex:
            detail = 'Error: {0}'.format(str(ex))
            raise ConnectionError(msg_template.format(url, detail))
        except requests.exceptions.SSLError as e:
            msg = 'Failed to reach API server due to SSL error {0}'
            repolib.error_and_exit(msg.format(e))
        return resp
        
    def _post_url(self, path, data = None, file = None):
        token = self._get_token()
        url = urljoin(self.base_url, path)
        http_headers = self._get_headers(token)
        
        if file:
            # File was specified. Need to read it.
            # Todo check file existence/contents
            del http_headers['Content-Type']
            filename = os.path.basename(file)
            files = {'file': [filename, open(file, 'rb')]}
            
            try:
                resp = requests.post(url, headers=http_headers, stream=False, verify=self.verify_ssl, files=files)
            except Exception as e:
                repolib.error_and_exit(e)
            return resp

        elif data:
            try:
                resp = requests.post(url, headers=http_headers, stream=False, verify=self.verify_ssl, data = json.dumps(data))
            except Exception as e:
                repolib.error_and_exit(e)
            return resp

    def _run_command(self, command):
        cmd_split = command.split(' ')
        res = check_output(cmd_split)
        return res.decode('utf-8')

    # Package Operations
    def list_packages(self):
        return self._get_url('packages')
        
    def upload_and_publish(self, file, repository_id):
        # Validate package, get name and version
        package_info = self.get_package_info(file)

        # Upload package to file API, get file ID
        resp_file = self.upload_file(file)
        response_json = json.loads(resp_file.text)
        package_info['fileId'] = response_json["id"]
        package_info['repositoryId'] = repository_id
        return self._post_url('packages', package_info)

    def upload_file(self, file):
        return self._post_url('files', file=file)

    def check_package_id(self, id):
        return self._get_url('packages/queue/{0}'.format(id))

    def delete_package_by_id(self, id):
        return self._delete_url('packages/{0}'.format(id))

    def get_package_info(self, file):
        if file.endswith('deb'):
            return self._get_package_info(file, 'dpkg-deb -I', ' Package:', ' Version:', ' Architecture:')
        elif file.endswith('rpm'):
            return self._get_package_info(file, 'rpm -qpi', 'Name', 'Version', 'Architecture')
        raise Exception('File {0} is neither deb nor rpm'.format(file))

    def _get_package_info(self, file, cmd, nameToken, versionToken, archToken):
        res = self._run_command('{0} {1}'.format(cmd, file))
        name = 'name'
        version = 'version'
        architecture = 'architecture'
        package_info = {}
        for line in res.split('\n'):
            if line.startswith(nameToken):
                package_info[name] = line.split(':')[1].strip()
            elif line.startswith(versionToken):
                # Version numbers can contain colons.
                # Remove everything before the first colon and recombine
                version_parts = line.split(':')[1:]
                package_info[version] = ':'.join(version_parts).strip()
            elif line.startswith(archToken):
                package_info[architecture] = line.split(':')[1].strip()
        if not name in package_info or not version in package_info or not architecture in package_info:
            raise Exception('Could not determine "name", "version", or "architecture" of package {0}'.format(file))
        return package_info

    # Repository Operations
    def list_repositories(self):
        return self._get_url('repositories')

    def add_repository(self, name, repo_type, editors, release = None, legacy_sign = False):
        data = {"url": name, "editors": editors, "type": repo_type}
        if release:
            data['distribution'] = release
        # Disable PRSS signing if legacy_sign is True
        data['prss'] = not legacy_sign
        return self._post_url('repositories', data = data)

    def delete_repository(self, id):
        return self._delete_url('repositories/{0}'.format(id))
        
